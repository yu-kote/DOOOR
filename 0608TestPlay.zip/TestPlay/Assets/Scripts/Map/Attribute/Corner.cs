﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Corner : AttributeBase
{
    void Start()
    {
        CreateAttribute("Corner");
    }
}
